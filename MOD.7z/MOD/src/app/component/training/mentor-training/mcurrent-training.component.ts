import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/services/training-service';


@Component({
    selector: 'mentor-current-training',
    templateUrl: './mcurrent-training.component.html'
})
export class McurrentTrainingComponent implements OnInit{
   
    public currentTrainingList;
mentorId : number;
mentorId1 : number = 12;
    constructor (private trainingService : TrainingService){

    }

    ngOnInit(): void {
        this.getMentorCurrentTrainingList(this.mentorId1);
      }
    
      getMentorCurrentTrainingList(mentorId : number) {
          this.trainingService.getMentorCurrentTrainingList(mentorId).subscribe(
          data => { this.currentTrainingList = data},
          err =>console.log(this.currentTrainingList),
          
           );
          
              
              }
  
}