import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/services/training-service';



@Component({
    selector: 'user-current-training',
    templateUrl: './ucurrent-training.component.html'
})
export class UcurrentTrainingComponent implements OnInit{
public currentTrainingList;
userId : number;
userId1 : number = 14;
    constructor (private trainingService : TrainingService){

    }
    ngOnInit(): void {
      this.getUserCurrentTrainingList(this.userId1);
    }

    getUserCurrentTrainingList(userId : number) {
this.trainingService.getUserCurrentTrainingList(userId).subscribe(
data => { this.currentTrainingList = data},
err =>console.log(this.currentTrainingList),

 );

    
    }
  
}