import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MentorService } from 'src/app/services/mentor-service';


@Component({
    selector: 'mentor-edit',
    templateUrl: './mentor-edit.component.html'
})
export class MentorEditComponent implements OnInit{
    @ViewChild('f', { static: true }) updateForm: NgForm;
    mentorEditStatus:boolean = false;

   /* mentor = {
        fullName : '',
        timing : '',
        technologies : '',
        facility : '',
        email : '',
        linkedUrl : '',
        qualification : '',
        experience : '',
        password : '',
       
      };
*/
      constructor(private router : Router , private mentorService : MentorService) {

    }

      onSubmit() {
    /*   this.mentor. fullName =  this.signUpForm.value.name;
       this.mentor. timing =  this.signUpForm.value.timing;
       this.mentor. technologies =  this.signUpForm.value.technologies;
       this.mentor. facility = this.signUpForm.value.facility;
       this.mentor. email =  this.signUpForm.value.email;
       this.mentor. linkedUrl =  this.signUpForm.value.linkedUrl;
       this.mentor. qualification =  this.signUpForm.value.qualification;
       this.mentor. experience =  this.signUpForm.value. experience;
       this.mentor. password =  this.signUpForm.value.password;  */
       this.mentorService. updateMentor(this.updateForm.value).subscribe();
     /*  this.mentorEditStatus = true;
       if(this.mentorEditStatus = true ) {
        this.router.navigate(['/user-login']);
       }
      */
    
     
     
      }
      
    ngOnInit(): void {
      
    }
  
}