import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';

import { Router } from '@angular/router';
import { UserService } from '../../services/user-service';
import { Observable } from 'rxjs/internal/Observable';



@Component({
    selector: 'user-register',
    templateUrl: './user-register.component.html'
})
export class UserRegisterComponent implements OnInit{
    @ViewChild('f', { static: true }) signUpForm: NgForm;  
    userSignUpStatus:boolean = false;
   
   
      constructor(private router : Router , private userService : UserService) {

      }

     
           
    onSubmit() {
   
      this.userSignUpStatus = true;
         this.userService.userRegister(this.signUpForm.value).subscribe();
         
         if(this.userSignUpStatus = true ) {
          this.router.navigate(['/user-login']);
         }
      }
    ngOnInit(): void {
      
    }
  
}